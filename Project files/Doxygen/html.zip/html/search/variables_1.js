var searchData=
[
  ['customtriplist_190',['customTripList',['../class_controller.html#a74697a9d68c134a1a3b89dc7f9aca406',1,'Controller']]]
];
