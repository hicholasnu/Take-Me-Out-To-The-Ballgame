var searchData=
[
  ['totaldistance_202',['totalDistance',['../class_graph.html#a5a8cd0381352d185be3ae5d33ee91d9f',1,'Graph']]],
  ['type_203',['type',['../struct_edge.html#af40348a361368d65f0c50df26cabf048',1,'Edge']]]
];
