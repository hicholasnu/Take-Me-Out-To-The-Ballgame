var searchData=
[
  ['setdestinationstadium_77',['setDestinationStadium',['../class_stadium_to_visit.html#a97bd74e7989a54ff458fe20a10ac1fd6',1,'StadiumToVisit']]],
  ['setdiscovery_78',['setDiscovery',['../class_graph.html#a8d6c5acd00c44b0aea619328994db81a',1,'Graph']]],
  ['setdistance_79',['setDistance',['../class_stadium_to_visit.html#a24e616208cfe0f77acba7700fe9cf33b',1,'StadiumToVisit']]],
  ['setoriginatedstadium_80',['setOriginatedStadium',['../class_stadium_to_visit.html#a8e5f4ea00e3a1574a6a8f3c98bd01cf9',1,'StadiumToVisit']]],
  ['setpassword_81',['setPassword',['../class_login.html#a2868a0882baf64f2774c83bf14bd78d9',1,'Login']]],
  ['setreverse_82',['setReverse',['../class_graph.html#a3e3f108832a2aadba3023721945dd2c9',1,'Graph']]],
  ['setusername_83',['setUsername',['../class_login.html#a5ee2258a2ea77bbd6c34aa0d6e5e4aa9',1,'Login']]],
  ['shortestdistance_84',['shortestDistance',['../class_graph.html#a063821ebc55a33765bcc59ccebf1ec62',1,'Graph']]],
  ['stadiumtovisit_85',['StadiumToVisit',['../class_stadium_to_visit.html',1,'StadiumToVisit'],['../class_stadium_to_visit.html#a9ac17c935568c4b10612d2ac5c7425b2',1,'StadiumToVisit::StadiumToVisit()']]],
  ['stadiumtovisit_2ecpp_86',['stadiumtovisit.cpp',['../stadiumtovisit_8cpp.html',1,'']]],
  ['stadiumtovisit_2eh_87',['stadiumtovisit.h',['../stadiumtovisit_8h.html',1,'']]],
  ['startspecificroute_88',['startSpecificRoute',['../class_graph.html#a4591a0fffe5fec3bf84cf2893c0a2910',1,'Graph::startSpecificRoute(QString vertex, int timesToRecurse)'],['../class_graph.html#a6233e622fcb1888d6034d07c4e58c1d1',1,'Graph::startSpecificRoute(QString vertex, int position, int length)']]]
];
