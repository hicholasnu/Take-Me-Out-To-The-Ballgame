var searchData=
[
  ['changetoadmin_126',['changeToAdmin',['../class_main_window.html#a51ef31d685e9ad1c34dcda10784d33d2',1,'MainWindow']]],
  ['changetouser_127',['changetoUser',['../class_main_window.html#a77889ef62824f31eebb6cd0875bb11d4',1,'MainWindow']]],
  ['checkavailablevertices_128',['checkAvailableVertices',['../class_graph.html#ab43777d26393bb154f368b6c2385c956',1,'Graph::checkAvailableVertices(QString vertex)'],['../class_graph.html#ab106abc83a2a96a14c49646ceaba68bd',1,'Graph::checkAvailableVertices(int adjListIndex)']]],
  ['clearedgetype_129',['clearEdgeType',['../class_graph.html#ae6587e7e72428a2f6bc5672dc841cbd7',1,'Graph']]],
  ['clearvisitedvertex_130',['clearVisitedVertex',['../class_graph.html#a9e4ca2c7386b819070281328226108d1',1,'Graph']]],
  ['controller_131',['Controller',['../class_controller.html#af888a35f7a377692726d81332edf08ab',1,'Controller::Controller(QObject *parent=nullptr)'],['../class_controller.html#a536df38104d2eed08a86219807214e54',1,'Controller::Controller(Controller &amp;controller)']]],
  ['createsouvenir_132',['createSouvenir',['../class_controller.html#ac05aa233ae22043a5786ee4287f282b4',1,'Controller']]],
  ['createtables_133',['createTables',['../class_controller.html#a897f9a9893d3a4d212681c20039f01b3',1,'Controller']]],
  ['customtrip_134',['customTrip',['../class_controller.html#a9b660458cdbb325de5499ddac89fcf95',1,'Controller']]]
];
